//
//  FirstViewController.swift
//  UITabControllerProject
//
//  Created by nebil on 11/16/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import UIKit

class FirstViewController: UIViewController {
    var timer = Timer()
    @IBOutlet weak var DisplayTime: UILabel!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    @objc func doItNow()  {
        let realTime = Date()
        let timeFormatter = DateFormatter()
        timeFormatter.dateFormat = "h:m:s"
        
        DisplayTime.text = timeFormatter.string(from: realTime)
    }
    
    
    @IBAction func StartTime(_ sender: Any) {
    
        timer = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(self.doItNow), userInfo: nil, repeats: true)
        
    
    }
    @IBAction func StopTime(_ sender: Any) {
     timer.invalidate()
    }
    
}

