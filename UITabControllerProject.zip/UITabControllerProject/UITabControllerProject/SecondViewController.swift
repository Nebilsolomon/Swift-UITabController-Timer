//
//  SecondViewController.swift
//  UITabControllerProject
//
//  Created by nebil on 11/16/18.
//  Copyright © 2018 nebilgokdemir. All rights reserved.
//

import UIKit

class SecondViewController: UIViewController {
  var timer = Timer()
    @IBOutlet weak var DisplayLabel: UILabel!
  
    @IBOutlet weak var TextFieldt: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        DisplayLabel.text = "🦐🦊🐬🐒🐝🐸"
    }
   
    @objc func JustDoIT()  {
      let myLabell = DisplayLabel.text
      let index = myLabell?.characters.index(after: (myLabell?.startIndex)!)
        let ch = myLabell?.substring(to: index!)
        let rest = myLabell?.substring(from: index!)
        let newCh = rest! + ch!
        DisplayLabel.text = newCh
    }
    
    
    @IBAction func StartTime(_ sender: Any) {
        timer = Timer.scheduledTimer(timeInterval: 0.25, target: self, selector: #selector(self.JustDoIT), userInfo: nil, repeats: true)
    
    }
    
    @IBAction func StopTime(_ sender: Any) {
    
    timer.invalidate()
    
    }
    
    
    @IBAction func InsertChINLabel(_ sender: Any) {
        
        if let x = TextFieldt.text{
        
            DisplayLabel.text =  DisplayLabel.text!+x
        
        }
        
}
    
    
    @IBAction func DeleteFirstCh(_ sender: Any) {
       
        if !timer.isValid
        {
            DisplayLabel.text = ""
            
        }
        else {
            print("Please Stop timer and than delete text of label")
        }
    }
    
    
}

